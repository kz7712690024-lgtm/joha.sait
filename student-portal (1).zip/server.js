const express = require("express");
const bodyParser = require("body-parser");
const session = require("express-session");
const bcrypt = require("bcrypt");

const app = express();
app.use(bodyParser.json());
app.use(session({ secret: "secret", resave: false, saveUninitialized: true }));
app.use(express.static("public"));

let users = [];
let feedbacks = [];

// Регистрация
app.post("/api/register", async (req, res) => {
    const { username, password } = req.body;
    if (users.find(u => u.username === username)) {
        return res.json({ error: "Такой пользователь уже есть" });
    }
    const hash = await bcrypt.hash(password, 10);
    users.push({
        username,
        password: hash,
        status: "pending",
        grades: { math: 100, it: 85, history: 90 },
        comments: []
    });
    res.json({ ok: true, message: "Регистрация успешна. Ждите подтверждения админа." });
});

// Логин
app.post("/api/login", async (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username);
    if (!user) return res.json({ error: "Пользователь не найден" });
    if (user.status !== "approved") return res.json({ error: "Админ еще не подтвердил" });

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.json({ error: "Пароль неверный" });

    req.session.user = { username: user.username };
    res.json({ ok: true, user: req.session.user });
});

// Получить оценки
app.get("/api/grades", (req, res) => {
    if (!req.session.user) return res.json({ error: "Не вошли" });
    const user = users.find(u => u.username === req.session.user.username);
    res.json({ ok: true, grades: user.grades });
});

// Добавить комментарий
app.post("/api/comment", (req, res) => {
    if (!req.session.user) return res.json({ error: "Не вошли" });
    const user = users.find(u => u.username === req.session.user.username);
    user.comments.push(req.body.comment);
    feedbacks.push({ user: user.username, text: req.body.comment });
    res.json({ ok: true });
});

// Админ: список pending
app.get("/api/admin/pending", (req, res) => {
    const pending = users.filter(u => u.status === "pending");
    res.json({ ok: true, pending });
});

// Админ: approve/reject
app.post("/api/admin/approve", (req, res) => {
    const { username, action } = req.body;
    const user = users.find(u => u.username === username);
    if (!user) return res.json({ error: "Нет такого пользователя" });

    if (action === "approve") {
        user.status = "approved";
    } else if (action === "reject") {
        user.status = "rejected";
    }
    res.json({ ok: true, message: `Пользователь ${action}` });
});

// Админ: все комментарии
app.get("/api/admin/feedbacks", (req, res) => {
    res.json({ ok: true, feedbacks });
});

// Выход
app.post("/api/logout", (req, res) => {
    req.session.destroy(() => res.json({ ok: true }));
});

app.listen(3000, () => console.log("Сервер запущен: http://localhost:3000"));
