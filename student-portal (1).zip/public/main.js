async function api(path, data) {
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });
  return res.json();
}

document.getElementById("registerForm").addEventListener("submit", async e => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const res = await api("/api/register", { username: fd.get("username"), password: fd.get("password") });
  alert(res.message || res.error);
});

document.getElementById("loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const res = await api("/api/login", { username: fd.get("username"), password: fd.get("password") });
  if (res.ok) {
    document.getElementById("auth").style.display = "none";
    document.getElementById("portal").style.display = "block";
    loadGrades();
  } else {
    alert(res.error);
  }
});

async function loadGrades() {
  const res = await fetch("/api/grades");
  const data = await res.json();
  const table = document.getElementById("gradesTable");
  table.innerHTML = "";
  if (data.ok) {
    for (let [subj, grade] of Object.entries(data.grades)) {
      let row = document.createElement("tr");
      row.innerHTML = `<td>${subj}</td><td>${grade}</td>`;
      table.appendChild(row);
    }
  }
}

document.getElementById("commentForm").addEventListener("submit", async e => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const res = await api("/api/comment", { comment: fd.get("comment") });
  if (res.ok) {
    alert("Комментарий сохранён");
    e.target.reset();
  } else {
    alert(res.error);
  }
});

document.getElementById("logoutBtn").addEventListener("click", async () => {
  await api("/api/logout", {});
  location.reload();
});