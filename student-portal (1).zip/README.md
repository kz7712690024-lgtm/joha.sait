# 🎓 Student Portal

Простой портал для студентов и админа.

## Функции
- Регистрация студентов
- Админ подтверждает или отклоняет регистрацию
- Авторизация после подтверждения
- Просмотр оценок
- Добавление комментариев
- Админ видит все комментарии

## Установка
```bash
git clone https://github.com/USERNAME/student-portal.git
cd student-portal
npm install
```

## Запуск
```bash
npm start
```

Откройте в браузере:
- Студенты: http://localhost:3000
- Админ: http://localhost:3000/admin.html
